from flask import Flask, request, jsonify
from utils.weather import get_weather
from utils.time import get_time
from utils.news import get_news
import requests

app = Flask(__name__)

OLLAMA_URL = "http://localhost:11434"
MODEL_NAME = "llama3"

@app.route("/chat", methods=["POST"])
def chat():
    user_msg = request.json.get("message", "").lower()

    if "weather" in user_msg:
        return jsonify({"reply": get_weather("jakarta")})
    elif "time" in user_msg:
        return jsonify({"reply": get_time("Asia/Jakarta")})
    elif "news" in user_msg:
        return jsonify({"reply": get_news()})

    response = requests.post(f"{OLLAMA_URL}/api/chat", json={
        "model": MODEL_NAME,
        "messages": [{"role": "user", "content": user_msg}]
    })

    data = response.json()
    reply = data["message"]["content"]
    return jsonify({"reply": reply})

if __name__ == "__main__":
    app.run(debug=True)
