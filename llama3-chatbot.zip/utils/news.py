import requests
import os

API_KEY = os.getenv("NEWSAPI_KEY", "your_newsapi_key")

def get_news():
    url = f"https://newsapi.org/v2/top-headlines?country=id&apiKey={API_KEY}"
    res = requests.get(url).json()
    articles = res.get("articles", [])[:3]
    news_list = [f"- {a['title']}" for a in articles]
    return "Here are the latest news headlines:\n" + "\n".join(news_list)
