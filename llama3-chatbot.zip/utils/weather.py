import requests
import os

API_KEY = os.getenv("OPENWEATHER_API_KEY", "your_openweather_api_key")

def get_weather(city="jakarta"):
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"
    res = requests.get(url).json()
    temp = res["main"]["temp"]
    desc = res["weather"][0]["description"]
    return f"The weather in {city.title()} is {desc} with {temp}°C."
