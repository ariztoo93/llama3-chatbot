import requests

def get_time(timezone="Asia/Jakarta"):
    res = requests.get(f"http://worldtimeapi.org/api/timezone/{timezone}").json()
    datetime_str = res["datetime"]
    time_only = datetime_str.split("T")[1][:5]
    return f"The current time in {timezone} is {time_only}."
