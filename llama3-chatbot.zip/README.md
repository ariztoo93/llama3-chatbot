# LLaMA 3 Chatbot

A chatbot using LLaMA 3 via Ollama + APIs for weather, time, and news.